from setuptools import setup

setup(

    name="paquete",
    version = "1.0",
    description = "Paquete distribuido con cliente y login",
    autor = "Gastón Pérez Camacho",
    autor_email = "Bopemiam@gmail.com",

    packages = ["paquete"]
)